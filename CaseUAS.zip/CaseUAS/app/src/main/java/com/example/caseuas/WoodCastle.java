package com.example.caseuas;


public class WoodCastle extends Castle{

    public WoodCastle(String name) {
        super(name);
    }

}

