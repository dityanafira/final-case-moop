package com.example.caseuas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Scanner;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {



        Scanner scan = new Scanner(System.in);
        Vector<Player> Players = new Vector<>();
        Vector<Hero> Heroes = new Vector<>();
        Vector<Castle> Castles = new Vector<>();
        Vector<Army> Armies = new Vector<>();

        public MainActivity() {

            int menu;

            do {
                System.out.println("Choose Number");
                System.out.println("1. Player A");
                System.out.println("2. Player B");
                System.out.println("3. Exit");
//			try {
//				menu = scan.nextInt();
//			} catch (Exception e) {
                menu = scan.nextInt();
                if(menu==1) {
                    PlayerA();
                }else if(menu ==2) {
                    PlayerB();
                }

            }while (menu !=3);



        }

        private void PlayerD() {
            // TODO Auto-generated method stub
            String name, castle, hero, army, Player;

            do {
                System.out.println("Choose castle [Horse / Steel / Stone / Wood] : ");
                castle = scan.nextLine();
            }while (!castle.equals("Horse")
                    && !castle.equals("Steel")
                    && !castle.equals("Stone")
                    && !castle.equals("Wood"));

            {
                System.out.println("Choose Army [Archer / Catapult / Cavalry / Infantry] : ");
                army = scan.nextLine();
            }while (!army.equals("Archer")
                    && !army.equals("Catapult")
                    && !army.equals("Cavalry")
                    && !army.equals("Infantry"));

            do {
                System.out.println("Choose Hero [Archer / Catapult / Cavalry / Infantry] : ");
                hero = scan.nextLine();
            }while (!hero.equals("Archer")
                    && !hero.equals("Catapult")
                    && !hero.equals("Cavalry")
                    && !hero.equals("Infantry"));

            System.out.println();
            System.out.println("Your Castle: " +castle);
            System.out.println("Your Army: " +army);
            System.out.println("Your Hero: " +hero);

        }

        private void PlayerC() {
            // TODO Auto-generated method stub
            String name, castle, hero, army, Player;

            do {
                System.out.println("Choose castle [Horse / Steel / Stone / Wood] : ");
                castle = scan.nextLine();
            }while (!castle.equals("Horse")
                    && !castle.equals("Steel")
                    && !castle.equals("Stone")
                    && !castle.equals("Wood"));

            {
                System.out.println("Choose Army [Archer / Catapult / Cavalry / Infantry] : ");
                army = scan.nextLine();
            }while (!army.equals("Archer")
                    && !army.equals("Catapult")
                    && !army.equals("Cavalry")
                    && !army.equals("Infantry"));

            do {
                System.out.println("Choose Hero [Archer / Catapult / Cavalry / Infantry] : ");
                hero = scan.nextLine();
            }while (!hero.equals("Archer")
                    && !hero.equals("Catapult")
                    && !hero.equals("Cavalry")
                    && !hero.equals("Infantry"));

            System.out.println("Your Castle: " +castle);
            System.out.println("Your Army: " +army);
            System.out.println("Your Hero: " +hero);

        }

        private void PlayerB() {
            // TODO Auto-generated method stub
            String name, castle, hero, army, Player;

            do {
                System.out.println("Choose castle [Horse / Steel / Stone / Wood] : ");
                castle = scan.nextLine();
            }while (!castle.equals("Horse")
                    && !castle.equals("Steel")
                    && !castle.equals("Stone")
                    && !castle.equals("Wood"));

            {
                System.out.println("Choose Army [Archer / Catapult / Cavalry / Infantry] : ");
                army = scan.nextLine();
            }while (!army.equals("Archer")
                    && !army.equals("Catapult")
                    && !army.equals("Cavalry")
                    && !army.equals("Infantry"));

            do {
                System.out.println("Choose Hero [Archer / Catapult / Cavalry / Infantry] : ");
                hero = scan.nextLine();
            }while (!hero.equals("Archer")
                    && !hero.equals("Catapult")
                    && !hero.equals("Cavalry")
                    && !hero.equals("Infantry"));

            System.out.println("Your Castle: " +castle);
            System.out.println("Your Army: " +army);
            System.out.println("Your Hero: " +hero);
        }

        private void PlayerA() {
            // TODO Auto-generated method stub
            String name, castle, hero, army, Player;

            do {
                System.out.println("Choose castle [Horse / Steel / Stone / Wood] : ");
                castle = scan.nextLine();
            }while (!castle.equals("Horse")
                    && !castle.equals("Steel")
                    && !castle.equals("Stone")
                    && !castle.equals("Wood"));

            {
                System.out.println("Choose Army [Archer / Catapult / Cavalry / Infantry] : ");
                army = scan.nextLine();
            }while (!army.equals("Archer")
                    && !army.equals("Catapult")
                    && !army.equals("Cavalry")
                    && !army.equals("Infantry"));

            do {
                System.out.println("Choose Hero [Archer / Catapult / Cavalry / Infantry] : ");
                hero = scan.nextLine();
            }while (!hero.equals("Archer")
                    && !hero.equals("Catapult")
                    && !hero.equals("Cavalry")
                    && !hero.equals("Infantry"));

            System.out.println("Your Castle: " +castle);
            System.out.println("Your Army: " +army);
            System.out.println("Your Hero: " +hero);
        }

        public static void main(String[] args) {
            new MainActivity();

        }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}