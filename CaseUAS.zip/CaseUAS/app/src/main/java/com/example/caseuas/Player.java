package com.example.caseuas;

import java.util.Vector;

public class Player {

    private Castle Castle;
    private String Player;

    public Vector<Hero> vHero = new Vector<Hero>();
    public Vector<Army> vArmy = new Vector<Army>();

    public Castle getCastle() {
        return Castle;
    }

    public Player(Castle namecastle, String player, Vector<Hero> vHero, Vector<Army> vArmy) {
        super();
        Castle = namecastle;
        Player = player;
        this.vHero = vHero;
        this.vArmy = vArmy;
    }

    public void setCastle(Castle namecastle) {
        Castle = namecastle;
    }

    public String getPlayer() {
        return Player;
    }

    public void setPlayer(String player) {
        Player = player;
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
