package com.example.caseuas;

public class InfantryHero extends Hero {

    public InfantryHero(String name) {
        super(name);
    }

}

