package com.example.caseuas;


public class StoneCastle extends Castle{

    public StoneCastle(String name) {
        super(name);
    }

}
