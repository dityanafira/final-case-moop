package com.example.caseuas;

public class SteelCastle extends Castle {

    public SteelCastle(String name) {
        super(name);
    }

}
