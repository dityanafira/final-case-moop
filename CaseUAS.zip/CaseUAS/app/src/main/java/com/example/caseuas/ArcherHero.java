package com.example.caseuas;

public class ArcherHero extends Hero {

    public ArcherHero(String name) {
        super(name);
    }

}
