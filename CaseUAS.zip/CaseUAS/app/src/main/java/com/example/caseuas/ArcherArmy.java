package com.example.caseuas;

public class ArcherArmy extends Army {
    public ArcherArmy(String name) {
        super(name);
    }
}
