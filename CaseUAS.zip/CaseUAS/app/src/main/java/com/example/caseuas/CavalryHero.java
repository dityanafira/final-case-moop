package com.example.caseuas;


public class CavalryHero extends Hero {

    public CavalryHero(String name) {
        super(name);
    }

}
