package com.example.caseuas;
public class HorseCastle extends Castle {

    public HorseCastle(String name) {
        super(name);
    }

}
