package com.example.caseuas;

public class Hero {

    public String name;


    public Hero (String name) {
        this.name=name;

    }

}