package com.example.caseuas;

public class CatapultArmy extends Army{

    public CatapultArmy(String name) {
        super(name);
    }

}
