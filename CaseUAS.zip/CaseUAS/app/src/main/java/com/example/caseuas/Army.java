package com.example.caseuas;

public class Army {

    public String name;


    public Army (String name) {
        this.name=name;

    }

}

