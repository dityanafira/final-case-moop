package com.example.caseuas;

public class Castle {

    public String name;


    public Castle (String name) {
        this.name=name;

    }

}

