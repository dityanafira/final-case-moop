package com.example.caseuas;

public class InfantryArmy extends Army{

    public InfantryArmy(String name) {
        super(name);
    }

}
