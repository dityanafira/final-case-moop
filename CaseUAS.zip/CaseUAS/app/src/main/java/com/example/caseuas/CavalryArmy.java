package com.example.caseuas;

public class CavalryArmy extends Army{

    public CavalryArmy(String name) {
        super(name);
    }

}
