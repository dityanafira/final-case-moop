package com.example.caseuas;

public class CatapultHero extends Hero {

    public CatapultHero(String name) {
        super(name);
        // TODO Auto-generated constructor stub
    }

}
